document.getElementById("open-canvas").addEventListener("click", function () {
    document.getElementById("canvas-open-close").classList.remove("d-none");
});
